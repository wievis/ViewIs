@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

chcp 65001 >nul
set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /f >nul 2>&1
net share ViewIsAddin /delete >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef" 2>nul
if exist "C:\ViewIsAddin" rmdir /s /q "C:\ViewIsAddin" >nul 2>&1
echo Dodatek ViewIs MEP zostal usuniety.
pause
