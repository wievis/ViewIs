@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Deinstalator ViewIs MEP Link

set "TARGET_DIR=C:\ViewIsAddin"
set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"
set "SHARE_NAME=ViewIsAddin"
set "SHARE_PS1=%TEMP%\viewis_unshare.ps1"

echo ========================================================
echo   Usuwanie dodatku ViewIs MEP
echo ========================================================
echo.

:waitexcel
tasklist /FI "IMAGENAME eq EXCEL.EXE" 2>nul | find /I "EXCEL.EXE" >nul
if not errorlevel 1 (
    echo Excel jest uruchomiony. Zamknij go i nacisnij dowolny klawisz.
    pause >nul
    goto :waitexcel
)

echo [1/4] Wpis rejestru Office...
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /f >nul 2>&1

echo [2/4] Cache dodatkow Excela...
if exist "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef" rmdir /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef" >nul 2>&1

echo [3/4] Udzial sieciowy (zapyta o zgode administratora)...
> "%SHARE_PS1%" echo if (Get-SmbShare -Name '%SHARE_NAME%' -ErrorAction SilentlyContinue) { Remove-SmbShare -Name '%SHARE_NAME%' -Force }
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%SHARE_PS1%'" >nul 2>&1
del "%SHARE_PS1%" >nul 2>&1

echo [4/4] Pliki %TARGET_DIR%...
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%" >nul 2>&1

echo.
set "LEFT="
reg query "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" >nul 2>&1
if not errorlevel 1 set "LEFT=wpis rejestru"
if exist "%TARGET_DIR%" set "LEFT=%LEFT% folder"
net share %SHARE_NAME% >nul 2>&1
if not errorlevel 1 set "LEFT=%LEFT% udzial"

if defined LEFT (
    echo UWAGA: nie wszystko udalo sie usunac, zostalo:%LEFT%
    echo Uruchom ponownie i zatwierdz okno UAC.
) else (
    echo Dodatek ViewIs MEP zostal usuniety. Mozesz uruchomic Excela.
)
echo.
pause
