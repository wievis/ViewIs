@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Wymagane uprawnienia administratora. Uruchamianie okna autoryzacji...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

chcp 65001 >nul
title Deinstalator ViewIs MEP Link

set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"
set "TARGET_DIR=C:\ViewIsAddin"

echo [1/3] Usuwanie wpisu rejestru Office...
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /f >nul 2>&1

echo [2/3] Zamykanie udzialu sieciowego ViewIsAddin...
net share ViewIsAddin /delete >nul 2>&1

echo [3/3] Usuwanie plikow z C:\ViewIsAddin...
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%" >nul 2>&1

echo.
echo Dodatek ViewIs MEP zostal pomyslnie usuniety.
pause
