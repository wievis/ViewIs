@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Wymagane uprawnienia administratora. Uruchamianie okna autoryzacji...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

chcp 65001 >nul
title Instalator ViewIs MEP Link

echo ========================================================
echo           Instalacja dodatku ViewIs MEP do programu Excel
echo ========================================================
echo.

set "TARGET_DIR=C:\ViewIsAddin"
set "MANIFEST_PATH=%TARGET_DIR%\viewis-mep-manifest.xml"
set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"

echo [1/4] Przygotowanie katalogu docelowego C:\ViewIsAddin...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

echo [2/4] Weryfikacja i kopiowanie pliku manifestu XML...
if exist "%~dp0viewis-mep-manifest.xml" (
    copy /y "%~dp0viewis-mep-manifest.xml" "%MANIFEST_PATH%" >nul
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://www.viewis.pl/mep/manifest.xml', '%MANIFEST_PATH%')"
)

echo [3/4] Konfiguracja lokalnego udzialu sieciowego UNC (\%COMPUTERNAME%\ViewIsAddin)...
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /f >nul 2>&1
net share ViewIsAddin="%TARGET_DIR%" /grant:"%USERNAME%",FULL >nul 2>&1

echo [4/4] Rejestracja wpisu w rejestrze programu Microsoft Excel...
set "UNC_PATH=\\%COMPUTERNAME%\ViewIsAddin"
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Id" /t REG_SZ /d "%CATALOG_ID%" /f >nul
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Url" /t REG_SZ /d "%UNC_PATH%" /f >nul
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Flags" /t REG_DWORD /d 1 /f >nul

echo.
echo ========================================================
echo   Instalacja zakonczona sukcesem!
echo   1. Uruchom program Microsoft Excel.
echo   2. W zakladce Home (lub Insert) kliknij Add-ins -> SHARED FOLDER.
echo   3. Dodatek ViewIs MEP Link jest gotowy do pracy.
echo ========================================================
echo.
pause
