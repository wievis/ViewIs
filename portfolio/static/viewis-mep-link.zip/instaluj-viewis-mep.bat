@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

chcp 65001 >nul
title Instalator ViewIs MEP Link

set "TARGET_DIR=C:\ViewIsAddin"
set "MANIFEST_PATH=%TARGET_DIR%\viewis-mep-manifest.xml"
set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

if exist "%~dp0viewis-mep-manifest.xml" (
    copy /y "%~dp0viewis-mep-manifest.xml" "%MANIFEST_PATH%" >nul
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://www.viewis.pl/mep/manifest.xml', '%MANIFEST_PATH%')"
)

net share ViewIsAddin="%TARGET_DIR%" /grant:"%USERNAME%",FULL >nul 2>&1

set "UNC_PATH=\\%COMPUTERNAME%\ViewIsAddin"
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Id" /t REG_SZ /d "%CATALOG_ID%" /f >nul
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Url" /t REG_SZ /d "%UNC_PATH%" /f >nul
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Flags" /t REG_DWORD /d 1 /f >nul

rmdir /s /q "%LOCALAPPDATA%\Microsoft\Office\16.0\Wef" 2>nul

echo ========================================================
echo   Instalacja zakonczona sukcesem!
echo   Uruchom Excel -> Home -> Add-ins -> SHARED FOLDER.
echo ========================================================
pause
