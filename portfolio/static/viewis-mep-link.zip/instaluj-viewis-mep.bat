@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Instalator ViewIs MEP Link

set "TARGET_DIR=C:\ViewIsAddin"
set "MANIFEST_PATH=%TARGET_DIR%\viewis-mep-manifest.xml"
set "CATALOG_ID={d7c4a194-48f8-4e89-a2e1-4c19d83e720a}"
set "SHARE_NAME=ViewIsAddin"
set "UNC_PATH=\\%COMPUTERNAME%\%SHARE_NAME%"
set "SHARE_PS1=%TARGET_DIR%\_share.ps1"

echo ========================================================
echo   Instalacja dodatku ViewIs MEP do programu Excel
echo ========================================================
echo.

tasklist /FI "IMAGENAME eq EXCEL.EXE" 2>nul | find /I "EXCEL.EXE" >nul
if not errorlevel 1 echo UWAGA: Excel jest uruchomiony. Po instalacji zamknij go i uruchom ponownie.
echo.

echo [1/4] Katalog %TARGET_DIR%...
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%" >nul 2>&1
if not exist "%TARGET_DIR%" goto :fail_dir

echo [2/4] Manifest...
if exist "%~dp0viewis-mep-manifest.xml" (
    copy /y "%~dp0viewis-mep-manifest.xml" "%MANIFEST_PATH%" >nul
) else (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; (New-Object Net.WebClient).DownloadFile('https://www.viewis.pl/mep/manifest.xml', '%MANIFEST_PATH%')" >nul 2>&1
)
if not exist "%MANIFEST_PATH%" goto :fail_manifest

echo [3/4] Udzial sieciowy %UNC_PATH% (zapyta o zgode administratora)...
> "%SHARE_PS1%" echo $ErrorActionPreference = 'Stop'
>> "%SHARE_PS1%" echo if (Get-SmbShare -Name '%SHARE_NAME%' -ErrorAction SilentlyContinue) { Remove-SmbShare -Name '%SHARE_NAME%' -Force }
>> "%SHARE_PS1%" echo $null = New-SmbShare -Name '%SHARE_NAME%' -Path '%TARGET_DIR%' -ReadAccess '%USERDOMAIN%\%USERNAME%'
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%SHARE_PS1%'" >nul 2>&1
del "%SHARE_PS1%" >nul 2>&1
dir "%UNC_PATH%\viewis-mep-manifest.xml" >nul 2>&1
if errorlevel 1 goto :fail_share

echo [4/4] Rejestracja w Excelu (biezacy uzytkownik)...
reg delete "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Id" /t REG_SZ /d "%CATALOG_ID%" /f >nul
if errorlevel 1 goto :fail_reg
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Url" /t REG_SZ /d "%UNC_PATH%" /f >nul
if errorlevel 1 goto :fail_reg
reg add "HKCU\Software\Microsoft\Office\16.0\WEF\TrustedCatalogs\%CATALOG_ID%" /v "Flags" /t REG_DWORD /d 1 /f >nul
if errorlevel 1 goto :fail_reg

echo.
echo ========================================================
echo   Instalacja zakonczona.
echo   1. Zamknij i uruchom ponownie Excela.
echo   2. Wstawianie - Moje dodatki - Folder udostepniony.
echo   3. Wybierz ViewIs MEP Link - Dodaj.
echo ========================================================
echo.
pause
exit /b 0

:fail_dir
echo BLAD: nie mozna utworzyc katalogu %TARGET_DIR%.
goto :fail
:fail_manifest
echo BLAD: brak manifestu (brak pliku w paczce i brak polaczenia z viewis.pl).
goto :fail
:fail_share
echo BLAD: nie udalo sie utworzyc udzialu %UNC_PATH%.
echo Mozliwe przyczyny: odmowa w oknie UAC, wylaczona usluga Serwer lub polityka firmy blokujaca udzialy.
goto :fail
:fail_reg
echo BLAD: nie udalo sie zapisac wpisu w rejestrze.
:fail
echo.
echo Instalacja NIE powiodla sie.
pause
exit /b 1
